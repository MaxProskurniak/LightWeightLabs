package com.example.datarest;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class DatabaseLoader implements CommandLineRunner {

    private final DogRepository repository;

    @Override
    public void run(String... strings) throws Exception {
        this.repository.saveAll(List.of(
                new Dog("1", "Doggy", 1, "Labr"),
                new Dog("2", "Nori", 2, "hound")
        ));
    }
}