package com.example.datarest;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.stereotype.Repository;

@Repository
@RepositoryRestResource(collectionResourceRel = "Dogs", path = "Dogs")
public interface DogRepository extends MongoRepository<Dog, String> {
}
