package com.example.datarest;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@ToString
public class Dog {
    @Id
    private String id;
    private String name;
    private int age;
    private String breed;
}
