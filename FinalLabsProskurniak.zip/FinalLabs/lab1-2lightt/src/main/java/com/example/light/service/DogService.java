package com.example.light.service;

import com.example.light.model.Dog;
import com.example.light.repository.DogRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class DogService {
    private final DogRepository repository;

    private List<Dog> Dogs = List.of(
            new Dog("1", "Doggy", 2, "Labr"),
            new Dog("2", "Nori", 1, "hound")

    );

//    @PostConstruct
//    void init() {
//        repository.saveAll(Dogs);
//    }

    @Cacheable("Dogs")
    public List<Dog> getDogs() {
        log.info("GET ALL DogS");
        return repository.findAll();
    }

    @Cacheable("Dogs")
    public Dog getDogById (String id) {
        log.info("GET Dog BY ID " + id);
        return repository.findById(id).orElse(null);
    }


    @CachePut(value="Dogs", key = "#Dog.id")
    public Dog createNewDog(Dog Dog){
        log.info("POST NEW Dog");
        return repository.save(Dog);
    }

    @CachePut(value="Dogs", key = "#Dog.id")
    public Dog updateDog(Dog Dog) {
        log.info("PATCH");
        return repository.save(Dog);
    }

    @CacheEvict("Dogs")
    public void deleteDogById(String id) {
        log.info("(=^･ｪ･^=) DELETE BY ID" + id);
        repository.deleteById(id);
    }


}
