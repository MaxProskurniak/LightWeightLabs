package com.example.light;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@EnableCaching
public class LightApplication {

    public static void main(String[] args) {
        SpringApplication.run(LightApplication.class, args);
    }

}
