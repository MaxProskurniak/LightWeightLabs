package com.example.light.controller;

import com.example.light.model.Dog;
import com.example.light.service.DogService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/Dogs")
@RequiredArgsConstructor
public class DogController {
    private final DogService service;

    @GetMapping("")
    public List<Dog> fetchDogs() {
        return service.getDogs();
    }

    @GetMapping("/{id}")
    public Dog fetchDog(@PathVariable String id){
        return service.getDogById(id);
    }

    @PostMapping
    public Dog insertDog(@RequestBody  Dog Dog){
        return service.createNewDog(Dog);
    }

    @PatchMapping
    public Dog updateDog(@RequestBody Dog Dog) {
        return service.updateDog(Dog);
    }

    @DeleteMapping("/{id}")
    public void deleteDog(@PathVariable String id) {
        service.deleteDogById(id);
    }

}
