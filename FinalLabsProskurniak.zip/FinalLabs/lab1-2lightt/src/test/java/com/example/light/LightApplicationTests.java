package com.example.light;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LightApplicationTests {

    @Test
    void contextLoads() {
    }

}
